'use client';

import React, { useState, useEffect } from 'react';
import { TradingBot, BotConfig, BotStats } from '@/lib/trading-bot';
import { Position } from '@/lib/deriv-api';
import { TradingSignal } from '@/lib/trading-strategies';
import { Play, Pause, Settings, TrendingUp, TrendingDown, DollarSign, Target, Activity, CircleAlert as AlertCircle } from 'lucide-react';

export default function TradingDashboard() {
  const [bot, setBot] = useState<TradingBot | null>(null);
  const [stats, setStats] = useState<BotStats>({
    totalTrades: 0,
    winningTrades: 0,
    losingTrades: 0,
    totalProfit: 0,
    dailyProfit: 0,
    winRate: 0,
    currentBalance: 0,
    isRunning: false
  });
  const [positions, setPositions] = useState<Position[]>([]);
  const [currentSignal, setCurrentSignal] = useState<TradingSignal | null>(null);
  const [config, setConfig] = useState<BotConfig>({
    derivConfig: {
      apiToken: process.env.NEXT_PUBLIC_DERIV_API_TOKEN || '',
      appId: parseInt(process.env.NEXT_PUBLIC_DERIV_APP_ID || '1089', 10)
    },
    symbol: 'R_100',
    tradeAmount: 1,
    maxDailyLoss: 50,
    maxDailyTrades: 20,
    riskPercentage: 2,
    strategy: 'COMBINED',
    enabled: false
  });
  const [showSettings, setShowSettings] = useState(false);

  const handleStartBot = async () => {
    if (!config.derivConfig.apiToken) {
      alert('Please enter your Deriv API token in settings');
      setShowSettings(true);
      return;
    }

    try {
      const newBot = new TradingBot(config);
      
      newBot.onStatsUpdated(setStats);
      newBot.onPositionsUpdated(setPositions);
      newBot.onSignalUpdated(setCurrentSignal);
      
      await newBot.start();
      setBot(newBot);
    } catch (error) {
      console.error('Failed to start bot:', error);
      alert('Failed to start bot. Please check your API token and connection.');
    }
  };

  const handleStopBot = async () => {
    if (bot) {
      await bot.stop();
      setBot(null);
    }
  };

  const handleConfigChange = (key: keyof BotConfig, value: any) => {
    setConfig(prev => ({
      ...prev,
      [key]: value
    }));
    
    if (bot) {
      bot.updateConfig({ [key]: value });
    }
  };

  const getSignalColor = (signal: TradingSignal | null) => {
    if (!signal) return 'text-gray-500';
    switch (signal.action) {
      case 'BUY_CALL': return 'text-green-500';
      case 'BUY_PUT': return 'text-red-500';
      default: return 'text-yellow-500';
    }
  };

  const getSignalIcon = (signal: TradingSignal | null) => {
    if (!signal) return <Activity className="w-4 h-4" />;
    switch (signal.action) {
      case 'BUY_CALL': return <TrendingUp className="w-4 h-4" />;
      case 'BUY_PUT': return <TrendingDown className="w-4 h-4" />;
      default: return <Activity className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Deriv Trading Bot</h1>
            <p className="text-gray-600 mt-1">Automated binary options trading</p>
          </div>
          
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
            >
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </button>
            
            {stats.isRunning ? (
              <button
                onClick={handleStopBot}
                className="flex items-center px-6 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
              >
                <Pause className="w-4 h-4 mr-2" />
                Stop Bot
              </button>
            ) : (
              <button
                onClick={handleStartBot}
                className="flex items-center px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
              >
                <Play className="w-4 h-4 mr-2" />
                Start Bot
              </button>
            )}
          </div>
        </div>

        {/* Settings Panel */}
        {showSettings && (
          <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Bot Configuration</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Deriv API Token
                </label>
                <input
                  type="password"
                  value={config.derivConfig.apiToken}
                  onChange={(e) => handleConfigChange('derivConfig', {
                    ...config.derivConfig,
                    apiToken: e.target.value
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter your API token"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Symbol
                </label>
                <select
                  value={config.symbol}
                  onChange={(e) => handleConfigChange('symbol', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="R_100">Volatility 100 Index</option>
                  <option value="R_75">Volatility 75 Index</option>
                  <option value="R_50">Volatility 50 Index</option>
                  <option value="R_25">Volatility 25 Index</option>
                  <option value="R_10">Volatility 10 Index</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Trade Amount ($)
                </label>
                <input
                  type="number"
                  value={config.tradeAmount}
                  onChange={(e) => handleConfigChange('tradeAmount', parseFloat(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0.35"
                  step="0.01"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Max Daily Loss ($)
                </label>
                <input
                  type="number"
                  value={config.maxDailyLoss}
                  onChange={(e) => handleConfigChange('maxDailyLoss', parseFloat(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="1"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Max Daily Trades
                </label>
                <input
                  type="number"
                  value={config.maxDailyTrades}
                  onChange={(e) => handleConfigChange('maxDailyTrades', parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="1"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Strategy
                </label>
                <select
                  value={config.strategy}
                  onChange={(e) => handleConfigChange('strategy', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="COMBINED">Combined (MA + RSI)</option>
                  <option value="MA_CROSSOVER">Moving Average Crossover</option>
                  <option value="RSI">RSI Strategy</option>
                </select>
              </div>
            </div>
            
            <div className="mt-6 flex items-center">
              <input
                type="checkbox"
                id="enabled"
                checked={config.enabled}
                onChange={(e) => handleConfigChange('enabled', e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="enabled" className="ml-2 block text-sm text-gray-900">
                Enable automated trading
              </label>
            </div>
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <DollarSign className="w-8 h-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Balance</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${stats.currentBalance.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <TrendingUp className="w-8 h-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Profit</p>
                <p className={`text-2xl font-bold ${stats.totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  ${stats.totalProfit.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Target className="w-8 h-8 text-purple-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Win Rate</p>
                <p className="text-2xl font-bold text-gray-900">
                  {stats.winRate.toFixed(1)}%
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Activity className="w-8 h-8 text-orange-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Trades</p>
                <p className="text-2xl font-bold text-gray-900">
                  {stats.totalTrades}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Current Signal */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Current Signal</h2>
          <div className="flex items-center space-x-4">
            <div className={`flex items-center ${getSignalColor(currentSignal)}`}>
              {getSignalIcon(currentSignal)}
              <span className="ml-2 font-medium">
                {currentSignal?.action || 'WAITING'}
              </span>
            </div>
            <div className="text-gray-600">
              Confidence: {currentSignal ? (currentSignal.confidence * 100).toFixed(1) : 0}%
            </div>
            <div className="text-gray-500">
              {currentSignal?.reason || 'Waiting for signal...'}
            </div>
          </div>
        </div>

        {/* Open Positions */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold">Open Positions</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Symbol
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Entry Price
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Current Price
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    P&L
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {positions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                      No open positions
                    </td>
                  </tr>
                ) : (
                  positions.map((position) => (
                    <tr key={position.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {position.symbol}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          position.tradeType === 'CALL' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {position.tradeType}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        ${position.amount.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {position.entryPrice.toFixed(5)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {position.currentPrice.toFixed(5)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={position.pnl >= 0 ? 'text-green-600' : 'text-red-600'}>
                          ${position.pnl.toFixed(2)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          position.status === 'open' 
                            ? 'bg-blue-100 text-blue-800' 
                            : position.status === 'closed'
                            ? 'bg-gray-100 text-gray-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {position.status}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}