import { DerivAPI, DerivConfig, TickData, TradeParams, Position } from './deriv-api';
import { TradingStrategy, TradingSignal } from './trading-strategies';

export interface BotConfig {
  derivConfig: DerivConfig;
  symbol: string;
  tradeAmount: number;
  maxDailyLoss: number;
  maxDailyTrades: number;
  riskPercentage: number;
  strategy: 'MA_CROSSOVER' | 'RSI' | 'COMBINED';
  enabled: boolean;
}

export interface BotStats {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  totalProfit: number;
  dailyProfit: number;
  winRate: number;
  currentBalance: number;
  isRunning: boolean;
}

export class TradingBot {
  private api: DerivAPI;
  private config: BotConfig;
  private strategy: TradingStrategy;
  private stats: BotStats;
  private positions: Position[] = [];
  private dailyTrades = 0;
  private dailyProfit = 0;
  private lastTradeTime = 0;
  private readonly minTimeBetweenTrades = 60000; // 1 minute
  private onStatsUpdate?: (stats: BotStats) => void;
  private onPositionUpdate?: (positions: Position[]) => void;
  private onSignalUpdate?: (signal: TradingSignal) => void;

  constructor(config: BotConfig) {
    this.config = config;
    this.api = new DerivAPI(config.derivConfig);
    this.strategy = new TradingStrategy();
    this.stats = {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      totalProfit: 0,
      dailyProfit: 0,
      winRate: 0,
      currentBalance: 0,
      isRunning: false
    };

    // Reset daily stats at midnight
    this.resetDailyStatsAtMidnight();
  }

  async start(): Promise<void> {
    try {
      await this.api.connect();
      this.stats.currentBalance = await this.api.getBalance();
      this.stats.isRunning = true;

      // Subscribe to price updates
      await this.api.subscribeTicks(this.config.symbol, (tick) => {
        this.handleTick(tick);
      });

      // Update positions periodically
      setInterval(() => {
        this.updatePositions();
      }, 5000);

      console.log(`Trading bot started for ${this.config.symbol}`);
      this.updateStats();
    } catch (error) {
      console.error('Failed to start trading bot:', error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    this.stats.isRunning = false;
    await this.api.unsubscribeTicks(this.config.symbol);
    this.api.disconnect();
    console.log('Trading bot stopped');
    this.updateStats();
  }

  private async handleTick(tick: TickData): Promise<void> {
    if (!this.config.enabled || !this.stats.isRunning) return;

    // Add price to strategy
    this.strategy.addPrice(tick.price);

    // Get trading signal based on selected strategy
    let signal: TradingSignal;
    switch (this.config.strategy) {
      case 'MA_CROSSOVER':
        signal = this.strategy.movingAverageCrossover();
        break;
      case 'RSI':
        signal = this.strategy.rsiStrategy();
        break;
      case 'COMBINED':
        signal = this.strategy.getCombinedSignal();
        break;
      default:
        signal = { action: 'HOLD', confidence: 0, reason: 'Unknown strategy' };
    }

    // Notify signal update
    if (this.onSignalUpdate) {
      this.onSignalUpdate(signal);
    }

    // Check if we should execute trade
    if (this.shouldExecuteTrade(signal)) {
      await this.executeTrade(signal, tick.price);
    }
  }

  private shouldExecuteTrade(signal: TradingSignal): boolean {
    // Don't trade if signal is HOLD
    if (signal.action === 'HOLD') return false;

    // Check confidence threshold
    if (signal.confidence < 0.6) return false;

    // Check daily limits
    if (this.dailyTrades >= this.config.maxDailyTrades) return false;
    if (this.dailyProfit <= -this.config.maxDailyLoss) return false;

    // Check time between trades
    const now = Date.now();
    if (now - this.lastTradeTime < this.minTimeBetweenTrades) return false;

    // Check balance
    if (this.stats.currentBalance < this.config.tradeAmount) return false;

    return true;
  }

  private async executeTrade(signal: TradingSignal, currentPrice: number): Promise<void> {
    try {
      const tradeType = signal.action === 'BUY_CALL' ? 'CALL' : 'PUT';
      
      const tradeParams: TradeParams = {
        symbol: this.config.symbol,
        tradeType,
        amount: this.config.tradeAmount,
        duration: 5, // 5 minutes
        durationType: 'm'
      };

      const result = await this.api.buyContract(tradeParams);
      
      if (result.buy) {
        this.dailyTrades++;
        this.lastTradeTime = Date.now();
        
        console.log(`Executed ${tradeType} trade:`, {
          symbol: this.config.symbol,
          amount: this.config.tradeAmount,
          price: currentPrice,
          reason: signal.reason
        });

        // Update stats
        this.stats.totalTrades++;
        this.updateStats();
      }
    } catch (error) {
      console.error('Failed to execute trade:', error);
    }
  }

  private async updatePositions(): Promise<void> {
    try {
      this.positions = await this.api.getOpenPositions();
      
      // Calculate profits from closed positions
      const closedPositions = this.positions.filter(p => p.status === 'closed');
      const newProfit = closedPositions.reduce((sum, pos) => sum + pos.pnl, 0);
      
      if (newProfit !== this.stats.totalProfit) {
        const profitDiff = newProfit - this.stats.totalProfit;
        this.stats.totalProfit = newProfit;
        this.dailyProfit += profitDiff;
        
        // Update win/loss counts
        closedPositions.forEach(pos => {
          if (pos.pnl > 0) {
            this.stats.winningTrades++;
          } else {
            this.stats.losingTrades++;
          }
        });
        
        this.updateStats();
      }

      if (this.onPositionUpdate) {
        this.onPositionUpdate(this.positions);
      }
    } catch (error) {
      console.error('Failed to update positions:', error);
    }
  }

  private updateStats(): void {
    this.stats.winRate = this.stats.totalTrades > 0 
      ? (this.stats.winningTrades / this.stats.totalTrades) * 100 
      : 0;

    if (this.onStatsUpdate) {
      this.onStatsUpdate({ ...this.stats });
    }
  }

  private resetDailyStatsAtMidnight(): void {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    
    const msUntilMidnight = tomorrow.getTime() - now.getTime();
    
    setTimeout(() => {
      this.dailyTrades = 0;
      this.dailyProfit = 0;
      this.updateStats();
      
      // Set up daily reset for subsequent days
      setInterval(() => {
        this.dailyTrades = 0;
        this.dailyProfit = 0;
        this.updateStats();
      }, 24 * 60 * 60 * 1000);
    }, msUntilMidnight);
  }

  // Event handlers
  onStatsUpdated(callback: (stats: BotStats) => void): void {
    this.onStatsUpdate = callback;
  }

  onPositionsUpdated(callback: (positions: Position[]) => void): void {
    this.onPositionUpdate = callback;
  }

  onSignalUpdated(callback: (signal: TradingSignal) => void): void {
    this.onSignalUpdate = callback;
  }

  // Getters
  getStats(): BotStats {
    return { ...this.stats };
  }

  getPositions(): Position[] {
    return [...this.positions];
  }

  updateConfig(newConfig: Partial<BotConfig>): void {
    this.config = { ...this.config, ...newConfig };
  }
}