import { TickData } from './deriv-api';

export interface TradingSignal {
  action: 'BUY_CALL' | 'BUY_PUT' | 'HOLD';
  confidence: number;
  reason: string;
}

export class TechnicalIndicators {
  static sma(prices: number[], period: number): number[] {
    const sma: number[] = [];
    for (let i = period - 1; i < prices.length; i++) {
      const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      sma.push(sum / period);
    }
    return sma;
  }

  static ema(prices: number[], period: number): number[] {
    const ema: number[] = [];
    const multiplier = 2 / (period + 1);
    
    // First EMA is SMA
    const firstSMA = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
    ema.push(firstSMA);
    
    for (let i = period; i < prices.length; i++) {
      const currentEMA = (prices[i] - ema[ema.length - 1]) * multiplier + ema[ema.length - 1];
      ema.push(currentEMA);
    }
    
    return ema;
  }

  static rsi(prices: number[], period: number = 14): number[] {
    const rsi: number[] = [];
    const gains: number[] = [];
    const losses: number[] = [];

    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1];
      gains.push(change > 0 ? change : 0);
      losses.push(change < 0 ? Math.abs(change) : 0);
    }

    for (let i = period - 1; i < gains.length; i++) {
      const avgGain = gains.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period;
      const avgLoss = losses.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period;
      
      if (avgLoss === 0) {
        rsi.push(100);
      } else {
        const rs = avgGain / avgLoss;
        rsi.push(100 - (100 / (1 + rs)));
      }
    }

    return rsi;
  }

  static macd(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) {
    const fastEMA = this.ema(prices, fastPeriod);
    const slowEMA = this.ema(prices, slowPeriod);
    
    const macdLine: number[] = [];
    const minLength = Math.min(fastEMA.length, slowEMA.length);
    
    for (let i = 0; i < minLength; i++) {
      macdLine.push(fastEMA[i] - slowEMA[i]);
    }
    
    const signalLine = this.ema(macdLine, signalPeriod);
    const histogram: number[] = [];
    
    for (let i = 0; i < signalLine.length; i++) {
      histogram.push(macdLine[i + macdLine.length - signalLine.length] - signalLine[i]);
    }
    
    return { macdLine, signalLine, histogram };
  }
}

export class TradingStrategy {
  private priceHistory: number[] = [];
  private readonly maxHistoryLength = 100;

  addPrice(price: number): void {
    this.priceHistory.push(price);
    if (this.priceHistory.length > this.maxHistoryLength) {
      this.priceHistory.shift();
    }
  }

  // Moving Average Crossover Strategy
  movingAverageCrossover(): TradingSignal {
    if (this.priceHistory.length < 20) {
      return { action: 'HOLD', confidence: 0, reason: 'Insufficient data' };
    }

    const shortMA = TechnicalIndicators.sma(this.priceHistory, 5);
    const longMA = TechnicalIndicators.sma(this.priceHistory, 20);

    if (shortMA.length < 2 || longMA.length < 2) {
      return { action: 'HOLD', confidence: 0, reason: 'Insufficient MA data' };
    }

    const currentShort = shortMA[shortMA.length - 1];
    const currentLong = longMA[longMA.length - 1];
    const prevShort = shortMA[shortMA.length - 2];
    const prevLong = longMA[longMA.length - 2];

    // Bullish crossover
    if (prevShort <= prevLong && currentShort > currentLong) {
      return { 
        action: 'BUY_CALL', 
        confidence: 0.7, 
        reason: 'Bullish MA crossover detected' 
      };
    }

    // Bearish crossover
    if (prevShort >= prevLong && currentShort < currentLong) {
      return { 
        action: 'BUY_PUT', 
        confidence: 0.7, 
        reason: 'Bearish MA crossover detected' 
      };
    }

    return { action: 'HOLD', confidence: 0.5, reason: 'No clear signal' };
  }

  // RSI Strategy
  rsiStrategy(): TradingSignal {
    if (this.priceHistory.length < 15) {
      return { action: 'HOLD', confidence: 0, reason: 'Insufficient data for RSI' };
    }

    const rsi = TechnicalIndicators.rsi(this.priceHistory);
    if (rsi.length === 0) {
      return { action: 'HOLD', confidence: 0, reason: 'No RSI data' };
    }

    const currentRSI = rsi[rsi.length - 1];

    if (currentRSI < 30) {
      return { 
        action: 'BUY_CALL', 
        confidence: 0.8, 
        reason: `RSI oversold at ${currentRSI.toFixed(2)}` 
      };
    }

    if (currentRSI > 70) {
      return { 
        action: 'BUY_PUT', 
        confidence: 0.8, 
        reason: `RSI overbought at ${currentRSI.toFixed(2)}` 
      };
    }

    return { action: 'HOLD', confidence: 0.3, reason: `RSI neutral at ${currentRSI.toFixed(2)}` };
  }

  // Combined Strategy
  getCombinedSignal(): TradingSignal {
    const maSignal = this.movingAverageCrossover();
    const rsiSignal = this.rsiStrategy();

    // If both signals agree
    if (maSignal.action === rsiSignal.action && maSignal.action !== 'HOLD') {
      return {
        action: maSignal.action,
        confidence: Math.min(maSignal.confidence + rsiSignal.confidence, 1.0),
        reason: `${maSignal.reason} + ${rsiSignal.reason}`
      };
    }

    // If signals conflict, prefer the higher confidence one
    if (maSignal.confidence > rsiSignal.confidence) {
      return maSignal;
    } else {
      return rsiSignal;
    }
  }
}