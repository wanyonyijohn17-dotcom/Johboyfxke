export interface DerivConfig {
  apiToken: string;
  appId: number;
  serverUrl?: string;
}

export interface TickData {
  symbol: string;
  price: number;
  timestamp: number;
}

export interface TradeParams {
  symbol: string;
  tradeType: 'CALL' | 'PUT';
  amount: number;
  duration: number;
  durationType: 's' | 'm' | 'h' | 'd';
}

export interface Position {
  id: string;
  symbol: string;
  tradeType: string;
  amount: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  status: 'open' | 'closed' | 'pending';
  timestamp: number;
}

export class DerivAPI {
  private ws: globalThis.WebSocket | null = null;
  private config: DerivConfig;
  private messageId = 1;
  private callbacks = new Map<number, (data: any) => void>();
  private tickSubscriptions = new Map<string, (tick: TickData) => void>();
  
  constructor(config: DerivConfig) {
    this.config = {
      serverUrl: 'wss://ws.binaryws.com/websockets/v3',
      ...config
    };
  }

  async connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(`${this.config.serverUrl}?app_id=${this.config.appId}`);

      this.ws.onopen = () => {
        console.log('Connected to Deriv API');
        this.authorize().then(resolve).catch(reject);
      };

      this.ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          this.handleMessage(message);
        } catch (error) {
          console.error('Error parsing message:', error);
        }
      };

      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        reject(error);
      };

      this.ws.onclose = () => {
        console.log('Disconnected from Deriv API');
      };
    });
  }

  private async authorize(): Promise<void> {
    return this.sendRequest({
      authorize: this.config.apiToken
    });
  }

  private handleMessage(message: any): void {
    // Handle tick data
    if (message.tick) {
      const callback = this.tickSubscriptions.get(message.tick.symbol);
      if (callback) {
        callback({
          symbol: message.tick.symbol,
          price: message.tick.quote,
          timestamp: message.tick.epoch * 1000
        });
      }
    }

    // Handle request responses
    if (message.req_id && this.callbacks.has(message.req_id)) {
      const callback = this.callbacks.get(message.req_id);
      if (callback) {
        callback(message);
        this.callbacks.delete(message.req_id);
      }
    }
  }

  private sendRequest(request: any): Promise<any> {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== globalThis.WebSocket.OPEN) {
        reject(new Error('WebSocket not connected'));
        return;
      }

      const reqId = this.messageId++;
      const message = { ...request, req_id: reqId };

      this.callbacks.set(reqId, (response) => {
        if (response.error) {
          reject(new Error(response.error.message));
        } else {
          resolve(response);
        }
      });

      this.ws.send(JSON.stringify(message));
    });
  }

  async subscribeTicks(symbol: string, callback: (tick: TickData) => void): Promise<void> {
    this.tickSubscriptions.set(symbol, callback);
    
    await this.sendRequest({
      ticks: symbol,
      subscribe: 1
    });
  }

  async unsubscribeTicks(symbol: string): Promise<void> {
    this.tickSubscriptions.delete(symbol);
    
    await this.sendRequest({
      forget_all: 'ticks'
    });
  }

  async getBalance(): Promise<number> {
    const response = await this.sendRequest({
      balance: 1
    });
    return response.balance?.balance || 0;
  }

  async buyContract(params: TradeParams): Promise<any> {
    const proposal = await this.sendRequest({
      proposal: 1,
      amount: params.amount,
      basis: 'stake',
      contract_type: params.tradeType,
      currency: 'USD',
      duration: params.duration,
      duration_unit: params.durationType,
      symbol: params.symbol
    });

    if (proposal.proposal) {
      return this.sendRequest({
        buy: proposal.proposal.id,
        price: params.amount
      });
    }

    throw new Error('Failed to get proposal');
  }

  async getOpenPositions(): Promise<Position[]> {
    const response = await this.sendRequest({
      portfolio: 1
    });

    return (response.portfolio?.contracts || []).map((contract: any) => ({
      id: contract.contract_id,
      symbol: contract.symbol,
      tradeType: contract.contract_type,
      amount: contract.buy_price,
      entryPrice: contract.entry_tick,
      currentPrice: contract.current_spot,
      pnl: contract.profit,
      status: contract.is_sold ? 'closed' : 'open',
      timestamp: contract.date_start * 1000
    }));
  }

  disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}